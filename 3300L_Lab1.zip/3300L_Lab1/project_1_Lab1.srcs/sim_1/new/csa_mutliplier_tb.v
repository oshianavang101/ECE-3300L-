`timescale 1ns / 1ps
 
module csa_multiplier_tb();
 
    reg [3:0] m, q;
    wire [7:0] p;
 
 csa_multiplier uut (

    .m(m),
    .q(q),
    .p(p)

    );
 
initial begin
 
        m = 4'd0;
        q = 4'd10;
        #10;
 
        m = 4'd5;
        q = 4'd5;
        #10;
 
        m = 4'd9;
        q = 4'd5;
        #10;
 
        m = 4'd12;
        q = 4'd13;
        #10;
 
        m = 4'd15;
        q = 4'd10;
        #10;
 
        $finish;
 
    end
 
endmodule
 
