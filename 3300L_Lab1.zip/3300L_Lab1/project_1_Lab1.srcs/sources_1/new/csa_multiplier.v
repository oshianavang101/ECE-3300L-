`timescale 1ns / 1ps
 
module csa_multiplier (

    input  [3:0] m,q,

    output [7:0] p

);
 


    // Partial products

  
 
    wire [3:0] mq0;

    wire [3:0] mq1;

    wire [3:0] mq2;

    wire [3:0] mq3;
 
 

    // Carry-save signals

  
 
    wire [3:0] cr0;

    wire [3:0] cr1;
 
    wire [2:0] sr0;

    wire [2:0] sr1;

    wire [2:0] cr2;
 
 
 

    // Partial products


 
    mq_4bit pp0 (

        .m(m),

        .q(q[0]),

        .mq(mq0)

    );
 
    mq_4bit pp1 (

        .m(m),

        .q(q[1]),

        .mq(mq1)

    );
 
    mq_4bit pp2 (

        .m(m),

        .q(q[2]),

        .mq(mq2)

    );
 
    mq_4bit pp3 (

        .m(m),

        .q(q[3]),

        .mq(mq3)

    );
 
 
 

    // Product bit 0


 
    assign p[0] = mq0[0];
 
 
 

    // Carry-save row 0


 
    full_adder r0_0 (

        .x(mq1[0]),

        .y(mq0[1]),

        .c_in(1'b0),

        .s(p[1]),

        .c_out(cr0[0])

    );
 
    full_adder r0_1 (

        .x(mq1[1]),

        .y(mq2[0]),

        .c_in(mq0[2]),

        .s(sr0[0]),

        .c_out(cr0[1])

    );
 
    full_adder r0_2 (

        .x(mq1[2]),

        .y(mq2[1]),

        .c_in(mq0[3]),

        .s(sr0[1]),

        .c_out(cr0[2])

    );
 
    full_adder r0_3 (

        .x(1'b0),

        .y(mq1[3]),

        .c_in(mq2[2]),

        .s(sr0[2]),

        .c_out(cr0[3])

    );
 
 


    // Carry-save row 1


 
    full_adder r1_0 (

        .x(cr0[0]),

        .y(1'b0),

        .c_in(sr0[0]),
        
        .s(p[2]),

        .c_out(cr1[0])

    );
 
    full_adder r1_1 (

        .x(cr0[1]),

        .y(mq3[0]),

        .c_in(sr0[1]),

        .s(sr1[0]),

        .c_out(cr1[1])

    );
 
    full_adder r1_2 (

        .x(cr0[2]),

        .y(mq3[1]),

        .c_in(sr0[2]),

        .s(sr1[1]),

        .c_out(cr1[2])

    );
 
    full_adder r1_3 (

        .x(cr0[3]),

        .y(mq3[2]),

        .c_in(mq2[3]),

        .s(sr1[2]),

        .c_out(cr1[3])

    );
 
 
 

    // Final ripple row


 
    full_adder r2_0 (

        .x(cr1[0]),

        .y(1'b0),

        .c_in(sr1[0]),

        .s(p[3]),

        .c_out(cr2[0])

    );
 
    full_adder r2_1 (

        .x(cr1[1]),

        .y(cr2[0]),

        .c_in(sr1[1]),

        .s(p[4]),

        .c_out(cr2[1])

    );
 
    full_adder r2_2 (

        .x(cr1[2]),

        .y(cr2[1]),

        .c_in(sr1[2]),

        .s(p[5]),

        .c_out(cr2[2])

    );
 
    full_adder r2_3 (

        .x(cr1[3]),

        .y(cr2[2]),

        .c_in(mq3[3]),

        .s(p[6]),

        .c_out(p[7])

    );
 
endmodule
 