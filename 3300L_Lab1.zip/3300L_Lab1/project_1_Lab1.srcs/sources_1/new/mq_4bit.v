`timescale 1ns / 1ps

module mq_4bit(
input[3:0]m,
input q,
output [3:0]mq
    );
 
generate 
    genvar k;
    
    for(k=0; k<4; k=k+1)
        begin: multiplybits
        
        assign mq[k] = m[k] & q;
        
        end
    endgenerate
endmodule
