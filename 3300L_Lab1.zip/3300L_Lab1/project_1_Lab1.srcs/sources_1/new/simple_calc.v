module simple_calc (
    input  [3:0] x, y,
    input  [1:0] op_sel,
 
    output [7:0] result,
    output       carry_out,
    output       overflow

);

wire [3:0] sum;
wire [7:0] product;
wire [7:0] sum_extended;

adder_subtractor #(.n(4)) add_sub (

        .x(x),
        .y(y),
        .add_n(op_sel[0]),
        .s(sum),
        .c_out(carry_out),
        .overflow(overflow)

    );
 
csa_multiplier multiplier (

        .m(x),
        .q(y),
        .p(product)

    );
 
    assign sum_extended = {4'b0000, sum};
 
    mux_2x1_8bit result_mux (

        .d0(sum_extended),

        .d1(product),

        .sel(op_sel[1]),

        .y(result)

    );
 
endmodule
 