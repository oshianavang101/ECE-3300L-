`timescale 1ns / 1ps

module bin2bcd_tb;

    reg  [7:0] bin;
    wire [11:0] bcd;

    bin2bcd uut (
        .bin(bin),
        .bcd(bcd)
    );

    initial begin

        bin = 8'd0;
        #10;

        bin = 8'd5;
        #10;

        bin = 8'd9;
        #10;

        bin = 8'd10;
        #10;

        bin = 8'd12;
        #10;

        bin = 8'd15;
        #10;

        bin = 8'd25;
        #10;

        bin = 8'd99;
        #10;

        bin = 8'd100;
        #10;

        bin = 8'd127;
        #10;

        bin = 8'd200;
        #10;

        bin = 8'd255;
        #10;

        $finish;

    end

endmodule
