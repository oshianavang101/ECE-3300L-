`timescale 1ns / 1ps

module add_3(
    input  [3:0] A,
    output [3:0] S
);

    assign S = (A >= 4'b0101) ? (A + 4'b0011) : A;

endmodule
