`timescale 1ns / 1ps

module bin2bcd(
    input  [7:0]  bin,
    output [11:0] bcd
);


    wire [19:0] stage0;
    wire [19:0] stage1;
    wire [19:0] stage2;
    wire [19:0] stage3;
    wire [19:0] stage4;
    wire [19:0] stage5;
    wire [19:0] stage6;
    wire [19:0] stage7;
    wire [19:0] stage8;

    wire [3:0] h0, t0, o0;
    wire [3:0] h1, t1, o1;
    wire [3:0] h2, t2, o2;
    wire [3:0] h3, t3, o3;
    wire [3:0] h4, t4, o4;
    wire [3:0] h5, t5, o5;
    wire [3:0] h6, t6, o6;
    wire [3:0] h7, t7, o7;

    assign stage0 = {12'b0, bin};

    add_3 a1_h(.A(stage0[19:16]), .S(h0));
    add_3 a1_t(.A(stage0[15:12]), .S(t0));
    add_3 a1_o(.A(stage0[11:8]),  .S(o0));

    assign stage1 = {
        h0,
        t0,
        o0,
        stage0[7:0]
    } << 1;


    add_3 a2_h(.A(stage1[19:16]), .S(h1));
    add_3 a2_t(.A(stage1[15:12]), .S(t1));
    add_3 a2_o(.A(stage1[11:8]),  .S(o1));

    assign stage2 = {
        h1,
        t1,
        o1,
        stage1[7:0]
    } << 1;


    add_3 a3_h(.A(stage2[19:16]), .S(h2));
    add_3 a3_t(.A(stage2[15:12]), .S(t2));
    add_3 a3_o(.A(stage2[11:8]),  .S(o2));

    assign stage3 = {
        h2,
        t2,
        o2,
        stage2[7:0]
    } << 1;



    add_3 a4_h(.A(stage3[19:16]), .S(h3));
    add_3 a4_t(.A(stage3[15:12]), .S(t3));
    add_3 a4_o(.A(stage3[11:8]),  .S(o3));

    assign stage4 = {
        h3,
        t3,
        o3,
        stage3[7:0]
    } << 1;



    add_3 a5_h(.A(stage4[19:16]), .S(h4));
    add_3 a5_t(.A(stage4[15:12]), .S(t4));
    add_3 a5_o(.A(stage4[11:8]),  .S(o4));

    assign stage5 = {
        h4,
        t4,
        o4,
        stage4[7:0]
    } << 1;



    add_3 a6_h(.A(stage5[19:16]), .S(h5));
    add_3 a6_t(.A(stage5[15:12]), .S(t5));
    add_3 a6_o(.A(stage5[11:8]),  .S(o5));

    assign stage6 = {
        h5,
        t5,
        o5,
        stage5[7:0]
    } << 1;


    add_3 a7_h(.A(stage6[19:16]), .S(h6));
    add_3 a7_t(.A(stage6[15:12]), .S(t6));
    add_3 a7_o(.A(stage6[11:8]),  .S(o6));

    assign stage7 = {
        h6,
        t6,
        o6,
        stage6[7:0]
    } << 1;


    add_3 a8_h(.A(stage7[19:16]), .S(h7));
    add_3 a8_t(.A(stage7[15:12]), .S(t7));
    add_3 a8_o(.A(stage7[11:8]),  .S(o7));

    assign stage8 = {
        h7,
        t7,
        o7,
        stage7[7:0]
    } << 1;

 
    assign bcd = stage8[19:8];

endmodule