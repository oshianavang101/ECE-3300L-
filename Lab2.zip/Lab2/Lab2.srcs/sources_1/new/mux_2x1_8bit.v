`timescale 1ns / 1ps

module mux_2x1_8bit(

input [7:0]x, y,
input s,
output [7:0]m

);
    
generate

genvar k;
    
    for(k=0; k < 8; k = k+1)
    begin: stage
    
    mux_2x1_simple(
    .x(x[k]),
    .y(y[k]),
    .s(s),
    .m(m[k])
     );
     
     end
     
  endgenerate 

endmodule
