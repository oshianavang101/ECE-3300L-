module simple_calc(
    input  [3:0]  x,
    input  [3:0]  y,
    input  [1:0]  op_sel,

    output [11:0] result,
    output        negative,
    output        carry_out,
    output        overflow
);

    wire [3:0] sum;
    wire [7:0] product;
    wire [7:0] raw_result;

    wire [11:0] bcd_positive;

    wire [7:0] magnitude;

    adder_subtractor #(.n(4)) AS0 (
        .x(x),
        .y(y),
        .add_n(op_sel[0]),
        .s(sum),
        .c_out(carry_out),
        .overflow(overflow)
    );


    csa_multiplier MULT0 (
        .m(x),
        .q(y),
        .p(product)
    );

    assign raw_result =
        op_sel[1] ? product :
        {4'b0000, sum};

    assign negative = (~op_sel[1]) &
                      op_sel[0] &
                      sum[3];

    assign magnitude =
        negative
        ? {4'b0000, (~sum + 4'b0001)}
        : raw_result;

    bin2bcd BCD0 (
        .bin(magnitude),
        .bcd(result)
    );

endmodule