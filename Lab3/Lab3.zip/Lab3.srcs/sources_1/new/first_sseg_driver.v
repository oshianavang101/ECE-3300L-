`timescale 1ns / 1ps

module first_sseg_driver(
    input [2:0] active_digit,
    input [3:0] num,
    input DP_ctrl,

    output [6:0] sseg,
    output [7:0] AN,
    output DP
);

    wire [7:0] decoded_digit; // Decoder output is from 0 through 7
    decoder_generic #(.N(3)) digit_decoder (   // Select one of the eight digits
        .w(active_digit),
        .en(1'b1),
        .y(decoded_digit)
    );
    // 4 bit number to seven-segment pattern
    hex2sseg number_decoder (
        .hex(num),
        .sseg(sseg)
    );

   genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : digit_select
            assign AN[i] = ~decoded_digit[i];
        end
    endgenerate
    assign DP = ~DP_ctrl;
endmodule