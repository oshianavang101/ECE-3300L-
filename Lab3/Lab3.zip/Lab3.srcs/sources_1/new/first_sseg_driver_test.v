`timescale 1ns / 1ps

module first_sseg_driver_test(
    input  [2:0] x,
    output [6:0] sseg,
    output [7:0] AN,
    output  DP
);

    first_sseg_driver driver_instance (
        .active_digit(x),
        .num({1'b0, x}),
        .DP_ctrl(1'b0),
        .sseg(sseg),
        .AN(AN),
        .DP(DP)
    );

endmodule