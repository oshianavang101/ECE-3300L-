`timescale 1ns / 1ps


module prior_encoder_test(
input [15:0] sw,
output [6:0] sseg,
output[7:0] AN
);

wire [3:0]y;
wire z;


priority_encoder_generic #(.N(16)) encoder_inst(
.w(sw),
.z(z),
.y(y)
);
assign AN={7'b1111111};

hex2sseg hex2segg_inst (
    .hex(y),
    .sseg(sseg)
    );
endmodule
