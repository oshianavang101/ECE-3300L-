`timescale 1ns / 1ps

module simple_calc_first_sseg(
    input [3:0] x,
    input [3:0] y,
    input  [1:0] op_sel,
    
    //these switches will select digits 4, 5, 6, 7
    input [1:0] digit_sel,
    
    output [6:0] sseg,
    output [7:0] AN,
    output       DP,
    output       carry_out,
    output       overflow
  );
    // Calculator result
    wire [7:0] calc_result;

    // Converted BCD result
    wire [11:0] bcd_result;

    // Three separate BCD digits
    wire [3:0] ones;
    wire [3:0] tens;
    wire [3:0] hundreds;

    // Digit selected by the MUX
    wire [3:0] selected_digit;

    // Connect board switches to calculator inputs
    wire [3:0] x;
    wire [3:0] y;
    wire [1:0] op_sel;

    // Split the 12-bit BCD result into three 4-bit digits
    assign ones    = bcd_result[3:0];
    assign tens    = bcd_result[7:4];
    assign hundreds = bcd_result[11:8];

    // Calculator
    simple_calc calculator_instance (
        .x(x),
        .y(y),
        .op_sel(op_sel),
        .result(calc_result),
        .carry_out(carry_out),
        .overflow(overflow)
    );

    // Convert binary result to BCD
    bin2bcd bcd_instance (
        .bin(calc_result),
        .bcd(bcd_result)
    );

    // SW9:SW8 selects which BCD digit is displayed
    mux_4x1_nbit #(.N(4)) digit_mux (
        .w0(ones),
        .w1(tens),
        .w2(hundreds),
        .w3(4'b0000),
        .s(digit_sel),
        .f(selected_digit)
    );

    // Select physical digits 4, 5, 6, or 7
    first_sseg_driver display_driver (
        .active_digit({1'b1, digit_select}),
        .num(selected_digit),
        .DP_ctrl(1'b0),
        .sseg(sseg),
        .AN(AN),
        .DP(DP)
    );

endmodule
